int g(size_t u)
{
  while (u < 30)
  {
    u++;
  }
  return u;
}

int h(int x, int y, int z)
{
  if (z == 0)
  {
    return x;
  }
  return y;
}
